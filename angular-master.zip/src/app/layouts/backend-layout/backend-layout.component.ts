import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-backend-layout',
  templateUrl: './backend-layout.component.html',
  styleUrls: ['./backend-layout.component.css']
})
export class BackendLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
