export interface Product {
    id: number;
    name: string;
    sku: string;
    price: number;
    is_active: number;
}
