import { UploadResponse } from './upload-response';

describe('UploadResponse', () => {
  it('should create an instance', () => {
    expect(new UploadResponse()).toBeTruthy();
  });
});
