export class UploadResponse {
    progress: number;
    files: [];
}
