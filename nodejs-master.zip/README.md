# nodejs-master

## Install Dependency Modules
Run `npm install`

## MySQL Database
Find database meanapp.sql in project root folder for database setup.
